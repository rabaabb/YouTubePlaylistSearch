/**
 Package containing classes supporting the core jsoup code.
 */
@NonnullByDefault
package org.jsoup.helper;

import org.jsoup.internal.NonnullByDefault;
